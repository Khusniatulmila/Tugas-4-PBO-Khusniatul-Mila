/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Luas_segitiga;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class luas_segitiga {
    
    public static void main(String[] args) {
       Scanner luas_segitiga = new Scanner(System.in);
       float alas, tinggi, luas;
       
       System.out.print("PROGRAM MENGHITUNG LUAS SEGITIGA\n");
       System.out.print("================================\n");
       System.out.print("Masukkan Nilai Alas = ");
       alas = luas_segitiga.nextInt();
       System.out.print("Masukkan Nilai Tinggi = ");
       tinggi = luas_segitiga.nextInt();
       luas = alas * tinggi/2;
       System.out.print("Luas Segitiga Adalah = "+luas+"\n");
    }
    
}
