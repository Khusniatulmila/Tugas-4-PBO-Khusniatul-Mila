/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Luas_Persegi_Panjang;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class luas_persegi_panjang {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner luas_persegi_panjang = new Scanner(System.in);
       float panjang, lebar, luas;
       
       System.out.print("PROGRAM MENGHITUNG LUAS PERSEGI PANJANG\n");
       System.out.print("================================\n");
       System.out.print("Masukkan Nilai Panjang = ");
       panjang = luas_persegi_panjang.nextInt();
       System.out.print("Masukkan Nilai Lebar = ");
       lebar = luas_persegi_panjang.nextInt();
       luas = panjang * lebar ;
       System.out.print("Luas Persegi Panjang  Adalah = "+luas+"\n");
    }
    
}
