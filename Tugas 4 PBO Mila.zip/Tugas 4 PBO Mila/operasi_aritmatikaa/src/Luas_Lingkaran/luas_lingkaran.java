/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Luas_Lingkaran;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class luas_lingkaran {

    
    public static void main(String[] args) {
       Scanner masukan = new Scanner(System.in);
       float jari, luas ;
       
       System.out.print("PROGRAM MENGHITUNG LUAS LINGKARAN\n");
       System.out.print("================================\n");
       System.out.print("Masukkan Nilai Variable Jari = ");
       jari = masukan.nextFloat();
       luas = (float)(3.14*jari*jari);
       System.out.print("Luas Lingkaran Adalah = "+luas+"\n");
    }
    
}
